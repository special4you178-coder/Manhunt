import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Set MANHUNT_URL to your deployed site (e.g. https://manhunt.vercel.app)
 * before running `npx cap sync`. The native shell loads that site, so game
 * updates ship without a new App Store release.
 */
const url = process.env.MANHUNT_URL;
if (!url) throw new Error("Set MANHUNT_URL to your deployed https:// address first.");

const config: CapacitorConfig = {
  appId: "com.manhunt.saida", // change once; it is permanent in the stores
  appName: "Manhunt",
  webDir: "public", // unused while server.url is set, but Capacitor requires it
  server: { url, cleartext: false },
  ios: {
    contentInset: "always",
    // Lets the web layer register a service worker (offline shell + map tiles).
    limitsNavigationsToAppBoundDomains: true,
  },
  plugins: {
    // Route fetch() through native HTTP so location uploads keep working
    // while the app is in the background.
    CapacitorHttp: { enabled: true },
  },
};

export default config;
