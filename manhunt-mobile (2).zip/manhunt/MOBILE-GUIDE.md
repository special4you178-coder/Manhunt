# HOSTING WITHOUT VERCEL (Render, free, no token)

1. Sign in at **render.com** with GitHub or Google.
2. Sign in at **neon.tech** and create a free database. Copy its connection string.
3. Put the project in a GitHub repository.
4. In Render: **New > Blueprint**, pick the repository (it reads `render.yaml`). When asked for `DATABASE_URL`, paste the Neon string.
5. Wait for the build. Your link is shown at the top, like `https://manhunt.onrender.com`. Use it as `MANHUNT_URL` and in the share links.

Notes: Render's free plan sleeps after 15 idle minutes, so the first player waits about a minute for it to wake. Open the link a couple of minutes before a hunt, or use the cheapest paid plan for always-on.
Other hosts: the included `Dockerfile` works on Google Cloud Run, Fly.io and Railway (set `DATABASE_URL`, port 8080).

---

# ANDROID APK WITHOUT ANDROID STUDIO (GitHub builds it for you)

This gives Android players real background location with no Play Store: they tap a link, install, play.

**One-time setup (about 15 minutes)**
1. Finish Step 1 (Vercel) so you have your site address.
2. Create a free GitHub account, make a **private** repository, upload this project (the `.gitignore` keeps junk out).
3. Make a signing key (needs Java installed; it is your app's permanent identity, keep the file safe and never share it):
   ```
   keytool -genkeypair -v -keystore release.jks -alias manhunt -keyalg RSA -keysize 2048 -validity 10000
   ```
   Then print it as text: Mac/Linux `base64 -w0 release.jks`, Windows PowerShell `[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.jks"))`.
4. In the repo: **Settings > Secrets and variables > Actions**
   - Secrets: `KEYSTORE_B64` (the long text), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (= `manhunt`)
   - Variable: `MANHUNT_URL` (= your Vercel address, https://...)
5. **Actions** tab > *Build Android APK* > **Run workflow**. After about 8 minutes the **Releases** page has `manhunt.apk`.

**Giving it to players:** send them the release's APK link. On their phone: download, tap it, allow "install unknown apps" for that browser, install, open, choose **Allow all the time** for location. They should keep "Battery: Unrestricted" for Manhunt on phones that kill background apps (Samsung, Xiaomi, Huawei).

Use the same key for every build so players can update over the old install.

---

# NO-STORE OPTION: just send a link (start here)

1. Deploy to Vercel (Step 1 below). You get one address, e.g. https://manhunt.vercel.app
2. Host creates a hunt, taps **Share** in the lobby. It sends a link like `https://manhunt.vercel.app/?join=ABC123`.
3. Players tap the link. The join screen opens with the code filled in. Pick a name and role, play.
4. Optional but recommended, add to Home Screen:
   - iPhone: open in **Safari** > Share > Add to Home Screen.
   - Android: open in Chrome > menu > Install app.

**The honest limit:** a web app can't track location with the screen locked or the app closed (iOS and Android both stop it). So in link mode the game keeps the screen awake while the hunt is live, shows "Keep this screen on and open", and restarts GPS when the player comes back. Players must leave Manhunt open in front. If someone switches apps, their position goes stale until they return.

If you need true background tracking with no store:
- **Android:** build the APK (Step 2) and host the file; players tap the link, allow "install unknown apps", install. No Play Store.
- **iPhone:** Apple has no store-free route for background apps except TestFlight (invite link, still needs the $99 account) or the App Store.

---

# Manhunt: iPhone + Android release guide

## What changed in this project
- `capacitor.config.ts`: native shell (iOS + Android) that loads your hosted game.
- `src/lib/native/background-location.ts`: background GPS (Android foreground service, iOS background mode); plain browser GPS on the web.
- `play-screen.tsx`: location uploads are now driven by the native watcher, so they continue with the screen locked. Real hunts show a **"Location must be on"** wall instead of tap-to-walk (rehearsal keeps tap-to-walk).
- `public/sw.js` + `offline-banner.tsx`: caches the app shell and map tiles; shows an offline banner.
- `native-config/`: permission snippets to paste into the generated iOS/Android projects.

## What "offline" means in this version
Works offline: the countdown clock, GPS tracking, the map you have already viewed, task pins and hold timers.
Needs a connection: seeker pings, catches, task confirmation, joining. These are server-decided, so two phones cannot play each other with no internet. Missed uploads resume on reconnect.
One-phone rehearsal needs only the first load.

## Step 1: host the backend (needed for multiplayer)
1. Create a free Postgres at neon.tech and copy its connection string.
2. Push this project to GitHub, import it in Vercel (the Nitro preset is already `vercel`).
3. Add env var `DATABASE_URL`, deploy. `npm run build` runs the migrations.
4. Open the Vercel URL on a phone and confirm a hunt can be created.

## Step 2: build the apps (on your computer)
```
npm install
export MANHUNT_URL=https://YOUR-SITE.vercel.app
npm run cap:add
# paste native-config snippets into Info.plist / AndroidManifest.xml
npx @capacitor/assets generate   # icons/splash from assets/icon.png (1024px)
npm run cap:sync
```
- Android: `npm run cap:android`, then Build > Generate Signed Bundle (AAB) in Android Studio. Test first with a debug APK on a real phone.
- iOS (Mac + Xcode required): `npm run cap:ios`, set your Team, enable the *Background Modes > Location updates* capability, then Product > Archive.

## Step 3: stores
- **Apple** ($99/yr): App Store Connect > new app > upload the archive > TestFlight test > submit. In the review notes explain *why* "Always" location is needed (hunt stays fair with the screen locked) and give a demo hunt code. Add a privacy policy URL and answer the location data questions.
- **Google Play** ($25 once): create the app, upload the AAB, complete the *Background location* declaration (with a short demo video) and the Data safety form. Closed testing with 12 testers for 14 days may be required for new personal accounts.

## Must-do before public release
1. **Map tiles:** the code uses CARTO/OSM public tiles. Their terms don't allow heavy app use or bulk pre-download. Switch to a paid/self-hosted provider (e.g. MapTiler, Stadia, or Protomaps) in `map-board.tsx`.
2. **Test on real phones** with the screen locked for 30+ minutes, on both platforms. I could not run builds or devices in my environment, so none of this is device-tested.
3. Ping schedule: hiders only get a ping if their last fix is under 3 minutes old; if you see missed pings, check battery-saver settings on the test phones.
4. The service worker on iOS depends on `WKAppBoundDomains`; if offline start-up fails on iPhone, the fallback is bundling a static build in the app (a bigger refactor I can do next).
