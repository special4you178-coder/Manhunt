// Adds the location/foreground-service permissions to the generated Android project.
import { readFileSync, writeFileSync } from "node:fs";

const file = process.argv[2] ?? "android/app/src/main/AndroidManifest.xml";
const perms = [
  "ACCESS_FINE_LOCATION",
  "ACCESS_COARSE_LOCATION",
  "ACCESS_BACKGROUND_LOCATION",
  "FOREGROUND_SERVICE",
  "FOREGROUND_SERVICE_LOCATION",
  "POST_NOTIFICATIONS",
];
let xml = readFileSync(file, "utf8");
const missing = perms.filter((p) => !xml.includes(`android.permission.${p}"`));
if (missing.length === 0) process.exit(0);
const block = missing.map((p) => `    <uses-permission android:name="android.permission.${p}" />\n`).join("");
if (!xml.includes("<application")) throw new Error("No <application> tag found in " + file);
xml = xml.replace("<application", `${block}\n    <application`);
writeFileSync(file, xml);
console.log("Added permissions:", missing.join(", "));
