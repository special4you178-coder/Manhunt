import { useEffect, useState, type FormEvent } from "react";
import { BookOpen, Copy, Shield, Users } from "lucide-react";
import { getState, joinGame, pairTeams, startGame, teamUp } from "@/lib/manhunt/api";
import {
  formatClock,
  formatCode,
  type HuntState,
  type Role,
} from "@/lib/manhunt/logic";

export function explain(err: unknown): string {
  if (err instanceof Error && err.message) return err.message;
  return "Something went wrong. Try again.";
}

function Credit() {
  return <p className="text-center text-sm font-semibold text-mute">Created by Omar Albaba</p>;
}

function ErrorNote({ text }: { text: string | null }) {
  if (!text) return null;
  return (
    <p className="border-l-4 border-blood pl-3 text-base font-semibold text-ink" role="alert">
      {text}
    </p>
  );
}

export function RulesScreen({ onDone, review }: { onDone: () => void; review?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-paper text-ink">
      <header className="bar safe-top flex items-center justify-between gap-3 px-4 py-3">
        <p className="font-display text-2xl tracking-wide">RULES</p>
        <p className="text-sm font-semibold text-paper">Saida</p>
      </header>
      <div className="min-h-0 flex-1 overflow-auto px-4 py-5">
        <div className="mx-auto flex max-w-xl flex-col gap-5">
          <div>
            <h1 className="font-display text-4xl">Manhunt</h1>
            <p className="mt-2 text-lg text-ink">
              Two seekers. Hiders in teams of two. The field is the public city between The Spot and Le Mall.
            </p>
          </div>
          <Rule n="1" title="The field">
            Play outdoors in Saida, on public ground between The Spot on Nazih El Bizri and Le Mall by the south
            roundabout. If a pin sits on a road, use the sidewalk. Do not enter homes, camps, schools, hospitals,
            prayer halls, or staff-only rooms.
          </Rule>
          <Rule n="2" title="Who plays">
            A hunt has exactly 2 seekers and any number of hiders. Everyone enters a name. The host names the hunt
            and sets the clock — 1 hour, 2 hours, or another length — before it starts.
          </Rule>
          <Rule n="3" title="Teams and tasks">
            Hiders pair into teams of 2. Each hider draws 6 tasks, so a team carries 12. Tasks are different for every
            hider. They are medium: go to a place, stay a short while, count, or read a sign. Nothing is for sale, and
            nothing gets broken.
          </Rule>
          <Rule n="4" title="Prayer pause">
            Anyone can pause the clock for prayer. The map stays, but the timer stops. Nobody is caught, and no task
            can be finished, until the pause is lifted.
          </Rule>
          <Rule n="5" title="Locations">
            Turn location on. The map is inside the app. Seeker phones receive hider positions every 10 minutes, not
            live. Hiders do not see each other on the map.
          </Rule>
          <Rule n="6" title="Immunity and score">
            Finish your 6 tasks and you are immune for the rest of the hunt. Seekers cannot catch you. Your score is
            the time left on the clock when you finished. More time left is better.
          </Rule>
          <Rule n="7" title="No phone chat">
            Hiders cannot message through the app. The only shared screen is a bump: if two hiders physically meet,
            each phone shows the other’s checklist. There is still no chat. Talk with your voice.
          </Rule>
          <Rule n="8" title="Fair play">
            Do not sabotage hiders. Do not hide their phones, block their path, grab them, or spoil a task. You may
            annoy the seekers a little — a decoy wave, a wrong turn you call out — and nothing past that. Nothing
            unsafe, illegal, or cruel.
          </Rule>
          <Rule n="9" title="A catch">
            A seeker confirms a catch only when they are standing with a hider who is not immune. The phones check
            that you are actually close. When the clock hits zero, hiders who never finished can still be caught.
          </Rule>
          <Rule n="10" title="Keep it on your phone">
            On iPhone: Share, then Add to Home Screen. On Android: the browser menu, then Install app or Add to Home
            screen. The hunt keeps running from the icon.
          </Rule>
          <Credit />
        </div>
      </div>
      <div className="safe-bottom border-t border-line px-4 pt-3">
        <div className="mx-auto max-w-xl">
          <button type="button" className="btn btn-primary w-full" onClick={onDone}>
            {review ? "Back to the hunt" : "Enter the hunt"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Rule({ n, title, children }: { n: string; title: string; children: string }) {
  return (
    <section className="border-l-4 border-blood pl-3">
      <h2 className="font-display text-2xl">
        {n}. {title}
      </h2>
      <p className="mt-1 text-lg text-pretty text-ink">{children}</p>
    </section>
  );
}

export function HomeScreen({
  onRules,
  onCreate,
  onJoin,
  onRehearse,
}: {
  onRules: () => void;
  onCreate: () => void;
  onJoin: () => void;
  onRehearse: () => void;
}) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bar safe-top flex items-center px-4 py-3">
        <button type="button" className="btn btn-line min-h-11 border-paper bg-ink text-paper" onClick={onRules}>
          <BookOpen className="size-5" aria-hidden />
          Rules
        </button>
      </header>
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col gap-6 px-4 py-8">
        <div>
          <p className="text-sm font-semibold tracking-widest text-blood">SAIDA</p>
          <h1 className="mt-1 font-display text-6xl">MANHUNT</h1>
          <p className="mt-3 text-lg">
            Two seekers hunt teams of hiders between The Spot and Le Mall. Six tasks each. Twelve to a team.
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <button type="button" className="btn btn-primary" onClick={onCreate}>
            Create a hunt
          </button>
          <button type="button" className="btn btn-ink" onClick={onJoin}>
            Join with a code
          </button>
          <button type="button" className="btn btn-line" onClick={onRehearse}>
            Rehearse on this phone
          </button>
        </div>
        <div className="mt-auto flex flex-col gap-2 text-base text-mute">
          <p>iPhone: Share, then Add to Home Screen.</p>
          <p>Android: browser menu, then Install app.</p>
          <Credit />
        </div>
      </main>
    </div>
  );
}

const PRESETS = [
  { minutes: 30, label: "30 min" },
  { minutes: 60, label: "1 hour" },
  { minutes: 90, label: "1.5 hours" },
  { minutes: 120, label: "2 hours" },
];

export function SetupScreen({
  mode,
  busy,
  error,
  onBack,
  onSubmit,
  initialCode,
}: {
  initialCode?: string;
  mode: "create" | "join" | "rehearse";
  busy: boolean;
  error: string | null;
  onBack: () => void;
  onSubmit: (value: { name: string; nickname: string; role: Role; minutes: number; code: string }) => void;
}) {
  const [name, setName] = useState("");
  const [nickname, setNickname] = useState("");
  const [code, setCode] = useState(initialCode ?? "");
  const [role, setRole] = useState<Role | null>(mode === "rehearse" ? "hider" : null);
  const [minutes, setMinutes] = useState(60);
  const [custom, setCustom] = useState("");
  const title = mode === "join" ? "Join a hunt" : mode === "rehearse" ? "Rehearse" : "Create a hunt";

  function submit(event: FormEvent) {
    event.preventDefault();
    if (!role) return;
    const picked = custom.trim() ? Number(custom) : minutes;
    onSubmit({ name: name.trim(), nickname: nickname.trim(), role, minutes: picked, code: code.trim() });
  }

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bar safe-top flex items-center gap-3 px-4 py-3">
        <button type="button" className="btn btn-line min-h-11 border-paper bg-ink text-paper" onClick={onBack}>
          Back
        </button>
        <h1 className="font-display text-2xl text-paper">{title}</h1>
      </header>
      <form className="mx-auto flex w-full max-w-md flex-1 flex-col gap-4 px-4 py-6" onSubmit={submit}>
        {mode === "create" || mode === "rehearse" ? (
          <label className="flex flex-col gap-1 font-semibold">
            Hunt name
            <input className="field font-normal" value={name} onChange={(e) => setName(e.target.value)} placeholder="Friday night" maxLength={32} required />
          </label>
        ) : (
          <label className="flex flex-col gap-1 font-semibold">
            Hunt code
            <input
              className="field font-display text-2xl tracking-widest uppercase"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="ABC 123"
              autoCapitalize="characters"
              maxLength={8}
              required
            />
          </label>
        )}
        <label className="flex flex-col gap-1 font-semibold">
          Your name
          <input className="field font-normal" value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="Omar" maxLength={18} required />
        </label>
        {mode === "rehearse" ? (
          <p className="text-base text-mute">Rehearsal puts you in as a hider. You can peek at the seeker map after it starts.</p>
        ) : (
          <fieldset className="flex flex-col gap-2">
            <legend className="font-semibold">You are</legend>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" className="btn btn-line" data-on={role === "hider"} onClick={() => setRole("hider")}>
                Hider
              </button>
              <button type="button" className="btn btn-line" data-on={role === "seeker"} onClick={() => setRole("seeker")}>
                Seeker
              </button>
            </div>
          </fieldset>
        )}
        {mode !== "join" ? (
          <fieldset className="flex flex-col gap-2">
            <legend className="font-semibold">Length</legend>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset.minutes}
                  type="button"
                  className="btn btn-line"
                  data-on={!custom && minutes === preset.minutes}
                  onClick={() => {
                    setMinutes(preset.minutes);
                    setCustom("");
                  }}
                >
                  {preset.label}
                </button>
              ))}
            </div>
            <label className="flex flex-col gap-1 text-base font-semibold">
              Or type minutes
              <input
                className="field font-normal"
                inputMode="numeric"
                value={custom}
                placeholder="45"
                onChange={(e) => setCustom(e.target.value.replace(/[^\d]/g, "").slice(0, 3))}
              />
            </label>
          </fieldset>
        ) : null}
        <ErrorNote text={error} />
        <button type="submit" className="btn btn-primary mt-2" disabled={busy || role == null}>
          {busy ? "One moment…" : mode === "join" ? "Join" : mode === "rehearse" ? "Start rehearsal" : "Open the lobby"}
        </button>
      </form>
    </div>
  );
}

export function LobbyScreen({
  session,
  onRules,
  onLeave,
  onLive,
}: {
  session: { gameId: string; token: string };
  onRules: () => void;
  onLeave: () => void;
  onLive: () => void;
}) {
  const [state, setState] = useState<HuntState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let stop = false;
    async function pull() {
      try {
        const next = await getState({ data: session });
        if (stop) return;
        setState(next);
        setError(null);
        if (next.status !== "lobby") onLive();
      } catch (err) {
        if (!stop) setError(explain(err));
      }
    }
    void pull();
    const id = window.setInterval(() => void pull(), 2500);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [session, onLive]);

  async function run(action: () => Promise<HuntState>) {
    setBusy(true);
    setError(null);
    try {
      const next = await action();
      setState(next);
      if (next.status !== "lobby") onLive();
    } catch (err) {
      setError(explain(err));
    } finally {
      setBusy(false);
    }
  }

  const ready = (state?.seekerCount ?? 0) === 2 && (state?.hiderCount ?? 0) >= 1;

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bar safe-top flex items-center justify-between gap-3 px-4 py-3">
        <button type="button" className="btn btn-line min-h-11 border-paper bg-ink text-paper" onClick={onRules}>
          <BookOpen className="size-5" aria-hidden />
          Rules
        </button>
        <button type="button" className="text-base font-semibold text-paper" onClick={onLeave}>
          Leave
        </button>
      </header>
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col gap-4 px-4 py-5">
        <div>
          <p className="text-sm font-semibold tracking-widest text-blood">LOBBY</p>
          <h1 className="font-display text-4xl">{state?.name ?? "Opening…"}</h1>
          <p className="mt-1 text-base text-mute">
            {state ? `${formatClock(state.durationMs)} on the clock` : "Loading the roster"}
          </p>
        </div>
        <div className="border border-ink p-4">
          <p className="text-sm font-semibold text-mute">Join code</p>
          <p className="font-display text-5xl tracking-wide">{formatCode(session.gameId)}</p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              className="btn btn-ink"
              onClick={() => {
                void navigator.clipboard?.writeText(session.gameId).then(() => {
                  setCopied(true);
                  window.setTimeout(() => setCopied(false), 1500);
                });
              }}
            >
              <Copy className="size-5" aria-hidden />
              {copied ? "Copied" : "Copy"}
            </button>
            <button
              type="button"
              className="btn btn-line"
              onClick={() => {
                const link = `${window.location.origin}/?join=${session.gameId}`;
                const text = `Manhunt in Saida. Tap to join: ${link} (code ${formatCode(session.gameId)})`;
                if (navigator.share) void navigator.share({ title: "Manhunt", text }).catch(() => undefined);
                else void navigator.clipboard?.writeText(text);
              }}
            >
              Share
            </button>
          </div>
        </div>
        <section className="flex flex-col gap-2">
          <h2 className="flex items-center gap-2 font-display text-2xl">
            <Users className="size-5" aria-hidden />
            Roster · seekers {state?.seekerCount ?? 0}/2
          </h2>
          <ul className="flex flex-col gap-2">
            {(state?.roster ?? []).map((player) => (
              <li key={player.nickname} className="flex items-center justify-between gap-2 border border-line px-3 py-3">
                <div className="min-w-0">
                  <p className="truncate text-lg font-semibold">{player.nickname}</p>
                  <p className="text-sm text-mute">
                    {player.role === "seeker" ? "Seeker" : "Hider"}
                    {player.team ? ` · Team ${player.team}` : ""}
                    {state?.me.nickname === player.nickname ? " · You" : ""}
                  </p>
                </div>
                {state?.me.role === "hider" && player.role === "hider" && player.nickname !== state.me.nickname ? (
                  <button
                    type="button"
                    className="btn btn-line min-h-11 shrink-0 px-3 text-base"
                    disabled={busy}
                    onClick={() => void run(() => teamUp({ data: { ...session, withName: player.nickname } }))}
                  >
                    {player.team && player.team === state.me.team ? "Unpair" : "Team up"}
                  </button>
                ) : null}
              </li>
            ))}
          </ul>
          <p className="text-base text-mute">
            Teams of 2 share 12 tasks, 6 each. If nobody pairs, the host’s start pairs hiders in join order.
          </p>
        </section>
        <ErrorNote text={error} />
        {state?.host ? (
          <div className="mt-auto flex flex-col gap-2">
            <button type="button" className="btn btn-line" disabled={busy} onClick={() => void run(() => pairTeams({ data: session }))}>
              Pair hiders into teams of 2
            </button>
            <button
              type="button"
              className="btn btn-primary"
              disabled={busy || !ready}
              onClick={() => void run(() => startGame({ data: { ...session, force: false } }))}
            >
              Start the hunt
            </button>
            {!ready ? (
              <button
                type="button"
                className="btn btn-ink"
                disabled={busy || (state?.hiderCount ?? 0) < 1}
                onClick={() => void run(() => startGame({ data: { ...session, force: true } }))}
              >
                Start with this roster anyway
              </button>
            ) : null}
            <p className="text-sm text-mute">
              A full hunt needs 2 seekers and at least 1 hider. The other button is only for a short practice start.
            </p>
          </div>
        ) : (
          <p className="mt-auto flex items-center gap-2 text-lg font-semibold">
            <Shield className="size-5 text-blood" aria-hidden />
            Waiting for the host to start.
          </p>
        )}
      </main>
    </div>
  );
}
