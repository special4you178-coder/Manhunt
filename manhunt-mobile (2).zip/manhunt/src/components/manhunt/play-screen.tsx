import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { BookOpen, Check, LocateFixed, Pause, Play, Shield, Trophy, X } from "lucide-react";
import { catchHider, completeTask, getState, setLocation, togglePause } from "@/lib/manhunt/api";
import {
  formatClock,
  haversine,
  inSaida,
  walkStart,
  type HuntState,
  type TaskView,
} from "@/lib/manhunt/logic";
import { MapBoard, type MapPin } from "./map-board";
import { isNative, useBackgroundLocation } from "@/lib/native/background-location";
import { useKeepAwake } from "@/lib/native/wake-lock";
import { explain } from "./screens";

type Fix = { lat: number; lng: number };

function Clock({ remainingMs, paused }: { remainingMs: number; paused: boolean }) {
  const anchor = useRef({ remainingMs, at: Date.now() });
  const [label, setLabel] = useState(() => formatClock(remainingMs));

  useEffect(() => {
    anchor.current = { remainingMs, at: Date.now() };
    setLabel(formatClock(remainingMs));
  }, [remainingMs, paused]);

  useEffect(() => {
    if (paused) return;
    let frame = 0;
    const loop = () => {
      const left = Math.max(0, anchor.current.remainingMs - (Date.now() - anchor.current.at));
      const next = formatClock(left);
      setLabel((prev) => (prev === next ? prev : next));
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [paused, remainingMs]);

  return (
    <p className="font-display text-5xl tabular-nums leading-none tracking-wide" aria-label={`Time left ${label}`}>
      {label}
    </p>
  );
}

export function PlayScreen({
  session,
  onLeave,
  onRules,
}: {
  session: { gameId: string; token: string };
  onLeave: () => void;
  onRules: () => void;
}) {
  const [state, setState] = useState<HuntState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [walk, setWalk] = useState<Fix | null>(null);
  const [sheet, setSheet] = useState<"tasks" | "scores" | null>(null);
  const [bumpOpen, setBumpOpen] = useState(false);
  const [peek, setPeek] = useState(false);
  const [hold, setHold] = useState<{ id: number; started: number } | null>(null);
  const [held, setHeld] = useState(0);
  const [answer, setAnswer] = useState("");
  const [picked, setPicked] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const bumpName = useRef<string | null>(null);
  const sentRef = useRef<{ lat: number; lng: number; at: number } | null>(null);
  const fixRef = useRef({ lat: 0, lng: 0, simulated: true });
  const lockedRef = useRef(false);

  useEffect(() => {
    let stop = false;
    async function pull() {
      try {
        const next = await getState({ data: session });
        if (stop) return;
        setState(next);
      } catch (err) {
        if (!stop) setError(explain(err));
      }
    }
    void pull();
    const id = window.setInterval(() => void pull(), 4000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [session]);

  useEffect(() => {
    const name = state?.bump?.nickname ?? null;
    if (name && name !== bumpName.current) {
      setBumpOpen(true);
      bumpName.current = name;
    }
    if (!name) bumpName.current = null;
  }, [state?.bump?.nickname]);

  const { fix: gps, status: gpsStatus, retry: armGps, openSettings } = useBackgroundLocation((f) => {
    // Driven by the native watcher so uploads continue with the screen locked.
    const last = sentRef.current;
    if (last && Date.now() - last.at < 8000) return;
    sentRef.current = { lat: f.lat, lng: f.lng, at: Date.now() };
    void setLocation({ data: { ...session, lat: f.lat, lng: f.lng, simulated: false } }).catch(() => {
      // Offline: drop it. The next fix (or the reconnect) carries the latest position.
    });
  });
  const gpsNote =
    gpsStatus === "denied"
      ? "Location is off for this app."
      : gpsStatus === "unavailable"
        ? "This phone cannot give a location."
        : null;

  useKeepAwake(!isNative() && state?.status === "live");

  useEffect(() => {
    // Coming back to the app (browser version): restart GPS right away.
    const back = () => {
      if (document.visibilityState === "visible") armGps();
    };
    document.addEventListener("visibilitychange", back);
    return () => document.removeEventListener("visibilitychange", back);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const gpsHere = gps != null && inSaida(gps.lat, gps.lng);
  // Real hunts need real location. Tap-to-walk is for rehearsal only.
  const locationLocked = state != null && !state.rehearsal && state.status === "live" && !gpsHere;
  const usingWalk = !gpsHere;
  const fix = gpsHere && gps ? gps : (walk ?? walkStart());
  fixRef.current = { lat: fix.lat, lng: fix.lng, simulated: usingWalk };
  lockedRef.current = locationLocked;

  useEffect(() => {
    let stop = false;
    async function send() {
      if (stop || lockedRef.current) return;
      const current = fixRef.current;
      sentRef.current = { lat: current.lat, lng: current.lng, at: Date.now() };
      try {
        const next = await setLocation({
          data: { ...session, lat: current.lat, lng: current.lng, simulated: current.simulated },
        });
        if (!stop) setState(next);
      } catch (err) {
        if (!stop) setError(explain(err));
      }
    }
    const kick = window.setTimeout(() => void send(), 800);
    const id = window.setInterval(() => void send(), 12000);
    return () => {
      stop = true;
      window.clearTimeout(kick);
      window.clearInterval(id);
    };
  }, [session]);

  useEffect(() => {
    const prev = sentRef.current;
    if (prev && haversine(prev.lat, prev.lng, fix.lat, fix.lng) < 20 && Date.now() - prev.at < 8000) return;
    const timer = window.setTimeout(() => {
      if (lockedRef.current) return;
      const current = fixRef.current;
      sentRef.current = { lat: current.lat, lng: current.lng, at: Date.now() };
      void setLocation({
        data: { ...session, lat: current.lat, lng: current.lng, simulated: current.simulated },
      })
        .then((next) => setState(next))
        .catch((err: unknown) => setError(explain(err)));
    }, 500);
    return () => window.clearTimeout(timer);
  }, [session, fix.lat, fix.lng, usingWalk]);

  useEffect(() => {
    if (!hold) return;
    let frame = 0;
    const loop = () => {
      setHeld(Date.now() - hold.started);
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [hold]);

  const seekerView = state?.me.role === "seeker" || (peek && state?.rehearsal);
  const pins: MapPin[] = useMemo(() => {
    if (!state) return [];
    const mine: MapPin[] = [{ id: "me", lat: fix.lat, lng: fix.lng, kind: "me", label: "" }];
    if (seekerView) {
      return [
        ...mine,
        ...state.roster
          .filter((player) => player.role === "hider" && player.ping)
          .map((player) => ({
            id: `ping-${player.nickname}`,
            lat: player.ping!.lat,
            lng: player.ping!.lng,
            kind: player.caught ? ("caught" as const) : player.immune ? ("immune" as const) : ("ping" as const),
            label: player.immune ? `${player.nickname} immune` : player.nickname,
          })),
      ];
    }
    return [
      ...mine,
      ...state.me.tasks.map((task) => ({
        id: `task-${task.id}`,
        lat: task.lat,
        lng: task.lng,
        kind: task.done ? ("done" as const) : ("task" as const),
        label: "",
      })),
    ];
  }, [state, fix.lat, fix.lng, seekerView]);

  async function onPause() {
    setBusy(true);
    try {
      setState(await togglePause({ data: session }));
      setError(null);
    } catch (err) {
      setError(explain(err));
    } finally {
      setBusy(false);
    }
  }

  async function onCatch() {
    setBusy(true);
    try {
      setState(await catchHider({ data: session }));
      setError(null);
    } catch (err) {
      setError(explain(err));
    } finally {
      setBusy(false);
    }
  }

  async function finish(task: TaskView) {
    setBusy(true);
    try {
      const next = await completeTask({ data: { ...session, taskId: task.id, answer } });
      setState(next);
      setError(null);
      setAnswer("");
      setHold(null);
      if (next.me.immune) setSheet("scores");
    } catch (err) {
      setError(explain(err));
    } finally {
      setBusy(false);
    }
  }

  const focus =
    state?.me.tasks.find((task) => task.id === picked && !task.done) ??
    state?.me.tasks.find((task) => !task.done) ??
    null;
  const meters = focus ? Math.round(haversine(fix.lat, fix.lng, focus.lat, focus.lng)) : null;
  const inside = focus != null && meters != null && meters <= focus.radius;
  const holdReady = focus != null && hold?.id === focus.id && held >= focus.staySec * 1000;

  useEffect(() => {
    if (!inside) setHold(null);
  }, [inside]);

  return (
    <div className="flex h-dvh flex-col bg-paper">
      <header className="bar safe-top z-20 px-3 pb-3 pt-2">
        <div className="flex items-start justify-between gap-3">
          <button type="button" className="btn btn-line min-h-11 border-paper bg-ink px-3 text-base text-paper" onClick={onRules}>
            <BookOpen className="size-5" aria-hidden />
            Rules
          </button>
          <div className="min-w-0 text-right">
            <p className="truncate text-lg font-semibold">{state?.me.nickname ?? "…"}</p>
            <p className="text-sm font-semibold tracking-wide text-paper">
              {state?.me.role === "seeker" ? "SEEKER" : "HIDER"}
              {state?.me.team ? ` · TEAM ${state.me.team}` : ""}
              {state?.me.immune ? " · IMMUNE" : ""}
              {state?.me.caught ? " · CAUGHT" : ""}
            </p>
          </div>
        </div>
        <div className="mt-2 flex flex-col items-center gap-2">
          <Clock remainingMs={state?.remainingMs ?? 0} paused={Boolean(state?.paused)} />
          <button type="button" className="btn btn-primary min-h-11 w-full max-w-sm text-base" disabled={busy || state?.status !== "live"} onClick={() => void onPause()}>
            {state?.paused ? <Play className="size-5" aria-hidden /> : <Pause className="size-5" aria-hidden />}
            {state?.paused ? "Resume the hunt" : "Pause for prayer"}
          </button>
        </div>
      </header>

      <div className="relative min-h-0 flex-1">
        <MapBoard
          pins={pins}
          walk={usingWalk}
          onPick={
            usingWalk
              ? (lat, lng) => {
                  setWalk({ lat, lng });
                }
              : undefined
          }
        />
        {locationLocked ? (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-paper/95 px-6 text-center">
            <p className="font-display text-3xl">Location must be on</p>
            <p className="text-base font-semibold">
              {gpsStatus === "denied"
                ? "Allow location for Manhunt (choose Always) so the hunt works with your screen locked."
                : "Waiting for your position inside the Saida field."}
            </p>
            <button type="button" className="btn btn-primary min-h-11 px-4 text-base" onClick={openSettings}>
              Open location settings
            </button>
            <button type="button" className="btn btn-line min-h-11 px-4 text-base" onClick={armGps}>
              Try again
            </button>
          </div>
        ) : null}
        {state?.paused ? (
          <div className="pointer-events-none absolute inset-x-4 top-16 border-4 border-blood bg-paper px-4 py-3 text-center">
            <p className="font-display text-3xl">Paused for prayer</p>
            <p className="text-base font-semibold">The clock is stopped. No catches. No tasks.</p>
          </div>
        ) : null}
        {state?.me.immune ? (
          <p className="pointer-events-none absolute inset-x-4 bottom-3 flex items-center justify-center gap-2 bg-ink px-3 py-2 text-center text-base font-semibold text-paper">
            <Shield className="size-5 text-blood" aria-hidden />
            Immune. Time left when you finished: {formatClock(state.me.scoreLeftMs ?? 0)}
          </p>
        ) : null}
        <button
          type="button"
          className="btn btn-ink absolute bottom-3 right-3 z-10 min-h-11 px-3 text-base"
          onClick={() => {
            armGps();
            if (gpsHere && gps) {
              setWalk(null);
            }
          }}
        >
          <LocateFixed className="size-5" aria-hidden />
          Location
        </button>
      </div>

      <footer className="safe-bottom z-20 border-t border-ink bg-paper px-3 pt-3">
        {error ? (
          <p className="mb-2 border-l-4 border-blood pl-3 text-sm font-semibold" role="alert">
            {error}
          </p>
        ) : (
          <p className="mb-2 text-center text-sm font-semibold text-mute">
            {state?.status === "ended"
              ? "Time is up."
              : seekerView
                ? `Next hider ping in ${formatClock(state?.nextPingMs ?? 0)}`
                : state?.me.partner
                  ? `Partner ${state.me.partner}. Your 6 of the team’s 12.`
                  : "Your 6 tasks. A partner makes the team 12."}
            {usingWalk ? " Walk mode is on." : ""}
            {!isNative() && state?.status === "live" ? " Keep this screen on and open." : ""}
            {gpsNote ? ` ${gpsNote}` : ""}
          </p>
        )}
        {state?.catchable && state.me.role === "seeker" && !state.paused ? (
          <button type="button" className="btn btn-primary mb-2 w-full" disabled={busy} onClick={() => void onCatch()}>
            Catch {state.catchable.nickname}
          </button>
        ) : null}
        <div className="grid grid-cols-2 gap-2">
          <button type="button" className="btn btn-ink" onClick={() => setSheet("tasks")}>
            {state?.me.role === "hider" ? `Tasks ${state.me.doneCount}/6` : "Hiders"}
          </button>
          <button type="button" className="btn btn-line" onClick={() => setSheet("scores")}>
            <Trophy className="size-5" aria-hidden />
            Scores
          </button>
        </div>
        {state?.rehearsal ? (
          <button type="button" className="btn btn-line mt-2 w-full text-base" data-on={peek} onClick={() => setPeek((v) => !v)}>
            {peek ? "Back to my hider map" : "Peek at the seeker map"}
          </button>
        ) : null}
        <button type="button" className="mt-2 w-full py-2 text-sm font-semibold text-mute" onClick={onLeave}>
          Leave this phone’s seat
        </button>
      </footer>

      {sheet ? (
        <Sheet title={sheet === "tasks" ? (state?.me.role === "hider" ? "Your tasks" : "Hiders") : "Scores"} onClose={() => setSheet(null)}>
          {sheet === "scores" || state?.me.role === "seeker" ? (
            <ScoreList state={state} />
          ) : (
            <div className="flex flex-col gap-3">
              <p className="text-base">
                {state?.me.team
                  ? `Team ${state.me.team} carries 12 tasks. These 6 are yours. ${state.me.partner ? `${state.me.partner} has the other 6 — compare when you bump into them.` : "Your partner has the other 6."}`
                  : "You have 6 tasks. Pair in the lobby next time so the team holds 12."}
              </p>
              <ul className="flex flex-col gap-2">
                {(state?.me.tasks ?? []).map((task, index) => (
                  <li key={task.id} className="border border-line p-3">
                    <p className="text-lg font-semibold">
                      {task.done ? <Check className="mr-1 inline size-5" aria-hidden /> : null}
                      {index + 1}. {task.title}
                    </p>
                    <p className="mt-1 text-base text-ink">{task.detail}</p>
                    {!task.done ? (
                      <button type="button" className="btn btn-line mt-2 w-full text-base" data-on={focus?.id === task.id} onClick={() => setPicked(task.id)}>
                        {focus?.id === task.id ? "Selected" : "Do this one"}
                      </button>
                    ) : null}
                  </li>
                ))}
              </ul>
              {focus && !state?.me.caught && !state?.me.immune && state?.status === "live" ? (
                <div className="border border-ink p-3">
                  <p className="font-semibold">Next up</p>
                  <p className="text-lg">{focus.title}</p>
                  {meters != null ? (
                    <p className="mt-1 text-base font-semibold">
                      {inside ? "You are inside the pin." : `${meters} m away. Get inside ${focus.radius} m.`}
                    </p>
                  ) : null}
                  {focus.note !== "none" ? (
                    <label className="mt-2 flex flex-col gap-1 text-base font-semibold">
                      {focus.note === "number" ? "The number you counted" : "Short answer"}
                      <input className="field font-normal" value={answer} onChange={(e) => setAnswer(e.target.value)} maxLength={24} />
                    </label>
                  ) : null}
                  {!holdReady ? (
                    <button
                      type="button"
                      className="btn btn-primary mt-3 w-full"
                      disabled={!inside || state?.paused || busy}
                      onClick={() => {
                        setHold({ id: focus.id, started: Date.now() });
                        setHeld(0);
                      }}
                    >
                      {hold?.id === focus.id
                        ? `Stay ${Math.max(0, focus.staySec - Math.floor(held / 1000))}s`
                        : `Start ${focus.staySec}s stay`}
                    </button>
                  ) : (
                    <button type="button" className="btn btn-primary mt-3 w-full" disabled={busy || state?.paused} onClick={() => void finish(focus)}>
                      Mark done
                    </button>
                  )}
                </div>
              ) : null}
            </div>
          )}
        </Sheet>
      ) : null}

      {bumpOpen && state?.bump ? (
        <Sheet title={`You bumped ${state.bump.nickname}`} onClose={() => setBumpOpen(false)}>
          <p className="text-lg">
            You are close enough to talk. There is no chat in the app.
            {state.bump.team ? ` They are on team ${state.bump.team}.` : ""}
          </p>
          <ul className="mt-3 flex flex-col gap-2">
            {state.bump.tasks.map((task) => (
              <li key={task.title} className="border border-line px-3 py-2 text-base">
                {task.done ? "Done · " : "Open · "}
                {task.title}
              </li>
            ))}
          </ul>
        </Sheet>
      ) : null}
    </div>
  );
}

function ScoreList({ state }: { state: HuntState | null }) {
  const rows = [...(state?.roster ?? [])].sort((a, b) => {
    if (a.role !== b.role) return a.role === "hider" ? -1 : 1;
    if (a.scoreLeftMs != null && b.scoreLeftMs == null) return -1;
    if (a.scoreLeftMs == null && b.scoreLeftMs != null) return 1;
    return (b.scoreLeftMs ?? 0) - (a.scoreLeftMs ?? 0);
  });
  return (
    <ul className="flex flex-col gap-2">
      {rows.map((player) => (
        <li key={`${player.role}-${player.nickname}`} className="flex items-center justify-between gap-3 border border-line px-3 py-3">
          <div>
            <p className="text-lg font-semibold">{player.nickname}</p>
            <p className="text-sm text-mute">
              {player.role === "seeker" ? "Seeker" : "Hider"}
              {player.team ? ` · Team ${player.team}` : ""}
              {player.ping ? ` · ping ${Math.round(player.ping.ageSec / 60)} min ago` : ""}
              {player.ping?.simulated ? " · not real GPS" : ""}
            </p>
          </div>
          <p className="text-right text-base font-semibold">
            {player.role === "seeker" ? "Seeking" : player.caught ? "Caught" : player.immune ? `${formatClock(player.scoreLeftMs ?? 0)} left` : "Hiding"}
          </p>
        </li>
      ))}
    </ul>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="scrim fixed inset-0 z-40 flex items-end" role="dialog" aria-modal="true" aria-label={title}>
      <div className="safe-bottom flex max-h-[85dvh] w-full flex-col border-t-4 border-blood bg-paper">
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <h2 className="font-display text-3xl">{title}</h2>
          <button type="button" className="btn btn-ink min-h-11 px-3" onClick={onClose}>
            <X className="size-5" aria-hidden />
            Close
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-auto px-4 pb-4">{children}</div>
      </div>
    </div>
  );
}
