import { useEffect, useRef, useState } from "react";
import "leaflet/dist/leaflet.css";
import { FIELD_BOUNDS, MALLS } from "@/lib/manhunt/logic";

export type MapPin = {
  id: string;
  lat: number;
  lng: number;
  kind: "mall" | "task" | "done" | "me" | "ping" | "immune" | "caught";
  label: string;
};

type MapBoardProps = {
  pins: MapPin[];
  walk: boolean;
  onPick?: (lat: number, lng: number) => void;
};

function esc(value: string): string {
  return value
    .replaceAll("&", "&" + "amp;")
    .replaceAll("<", "&" + "lt;")
    .replaceAll(">", "&" + "gt;")
    .replaceAll('"', "&" + "quot;")
    .replaceAll("'", "&" + "#39;");
}

export function MapBoard({ pins, walk, onPick }: MapBoardProps) {
  const elRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const groupRef = useRef<import("leaflet").LayerGroup | null>(null);
  const [ready, setReady] = useState(false);
  const pickRef = useRef(onPick);
  pickRef.current = onPick;

  useEffect(() => {
    const el = elRef.current;
    if (!el) return;
    let alive = true;
    let map: import("leaflet").Map | null = null;

    void (async () => {
      const mod = await import("leaflet");
      const L = mod.default ?? mod;
      if (!alive || !elRef.current) return;
      const host = elRef.current;
      if ((host as HTMLElement & { _leaflet_id?: number })._leaflet_id) return;

      map = L.map(host, {
        zoomControl: false,
        attributionControl: true,
        minZoom: 14,
        maxZoom: 18,
      });
      const bounds = L.latLngBounds(
        [FIELD_BOUNDS.south, FIELD_BOUNDS.west],
        [FIELD_BOUNDS.north, FIELD_BOUNDS.east],
      );
      map.fitBounds(bounds, { padding: [28, 28] });
      map.setMaxBounds(bounds.pad(0.35));
      L.control.zoom({ position: "bottomright" }).addTo(map);

      const tiles = L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        subdomains: "abcd",
        maxZoom: 20,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; CARTO',
      });
      let failed = 0;
      tiles.on("tileerror", () => {
        failed += 1;
        if (failed === 3 && map) {
          map.removeLayer(tiles);
          L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
          }).addTo(map);
        }
      });
      tiles.addTo(map);
      groupRef.current = L.layerGroup().addTo(map);
      map.on("click", (event) => {
        pickRef.current?.(event.latlng.lat, event.latlng.lng);
      });
      mapRef.current = map;
      setReady(true);
      window.setTimeout(() => map?.invalidateSize(), 180);
    })();

    return () => {
      alive = false;
      map?.remove();
      mapRef.current = null;
      groupRef.current = null;
      setReady(false);
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const group = groupRef.current;
    if (!map || !group) return;
    void import("leaflet").then((mod) => {
      const L = mod.default ?? mod;
      group.clearLayers();
      const malls: MapPin[] = [
        { id: "mall-spot", lat: MALLS.spot.lat, lng: MALLS.spot.lng, kind: "mall", label: "The Spot" },
        { id: "mall-le", lat: MALLS.leMall.lat, lng: MALLS.leMall.lng, kind: "mall", label: "Le Mall" },
      ];
      for (const pin of [...malls, ...pins]) {
        const wide = pin.kind === "mall" || pin.kind === "ping" || pin.kind === "immune" || pin.kind === "caught";
        const icon = L.divIcon({
          className: "hunt-marker",
          html: `<div class="pin pin-${pin.kind}">${esc(pin.label)}</div>`,
          iconSize: wide ? [132, 28] : [18, 18],
          iconAnchor: wide ? [66, 14] : [9, 9],
        });
        L.marker([pin.lat, pin.lng], { icon, keyboard: false, interactive: false }).addTo(group);
      }
    });
  }, [pins, ready]);

  return (
    <div className="absolute inset-0">
      <div ref={elRef} className="hunt-map" role="application" aria-label="Map of Saida between The Spot and Le Mall" />
      {walk ? (
        <p className="pointer-events-none absolute inset-x-3 top-3 rounded-md bg-paper/95 px-3 py-2 text-sm font-semibold text-ink shadow">
          Tap the map to walk. Turn on location when you are in Saida.
        </p>
      ) : null}
    </div>
  );
}
