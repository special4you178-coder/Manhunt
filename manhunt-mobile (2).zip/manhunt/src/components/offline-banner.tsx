import { useEffect, useState } from "react";

/** Registers the offline service worker and shows a banner while disconnected. */
export function OfflineBanner() {
  const [online, setOnline] = useState(true);

  useEffect(() => {
    if ("serviceWorker" in navigator && !import.meta.env.DEV) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);

  if (online) return null;
  return (
    <p className="safe-top fixed inset-x-0 top-0 z-50 bg-ink px-3 py-1 text-center text-sm font-semibold text-paper">
      Offline. Your clock and GPS keep running. Pings and catches sync when you reconnect.
    </p>
  );
}
