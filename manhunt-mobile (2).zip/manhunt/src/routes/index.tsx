import { useCallback, useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { createGame, getState, joinGame } from "@/lib/manhunt/api";
import type { Role } from "@/lib/manhunt/logic";
import { PlayScreen } from "@/components/manhunt/play-screen";
import {
  HomeScreen,
  LobbyScreen,
  RulesScreen,
  SetupScreen,
  explain,
} from "@/components/manhunt/screens";

export const Route = createFileRoute("/")({ component: Home });

type Phase = "rules" | "home" | "create" | "join" | "rehearse" | "lobby" | "play";
type Session = { gameId: string; token: string };

const STORAGE = "manhunt.session.v1";
const RULES = "manhunt.rules.v1";

function Home() {
  const [phase, setPhase] = useState<Phase>("rules");
  const [session, setSession] = useState<Session | null>(null);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState("");

  useEffect(() => {
    const fromLink = new URLSearchParams(window.location.search).get("join")?.toUpperCase().replace(/[^A-Z0-9]/g, "") ?? "";
    const landing = (seen: boolean): Phase => {
      if (fromLink.length === 6) {
        setJoinCode(fromLink);
        return "join";
      }
      return seen ? "home" : "rules";
    };
    let seen = false;
    try {
      seen = localStorage.getItem(RULES) === "1";
      const raw = localStorage.getItem(STORAGE);
      if (raw) {
        const parsed = JSON.parse(raw) as Session;
        if (parsed.gameId && parsed.token) {
          setSession(parsed);
          void getState({ data: parsed })
            .then((next) => setPhase(next.status === "lobby" ? "lobby" : "play"))
            .catch(() => {
              localStorage.removeItem(STORAGE);
              setSession(null);
              setPhase(landing(seen));
            });
          return;
        }
      }
    } catch {
      localStorage.removeItem(STORAGE);
    }
    setPhase(landing(seen));
  }, []);

  function remember(next: Session) {
    localStorage.setItem(STORAGE, JSON.stringify(next));
    localStorage.setItem(RULES, "1");
    setSession(next);
  }

  function leave() {
    localStorage.removeItem(STORAGE);
    setSession(null);
    setError(null);
    setPhase("home");
  }

  const onLive = useCallback(() => setPhase("play"), []);

  async function submit(
    mode: "create" | "join" | "rehearse",
    value: { name: string; nickname: string; role: Role; minutes: number; code: string },
  ) {
    setBusy(true);
    setError(null);
    try {
      const next =
        mode === "join"
          ? await joinGame({ data: { gameId: value.code, nickname: value.nickname, role: value.role } })
          : await createGame({
              data: {
                name: value.name,
                nickname: value.nickname,
                role: value.role,
                minutes: value.minutes,
                rehearsal: mode === "rehearse",
              },
            });
      remember(next);
      setPhase(mode === "rehearse" ? "play" : "lobby");
    } catch (err) {
      setError(explain(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {phase === "rules" ? (
        <RulesScreen
          onDone={() => {
            localStorage.setItem(RULES, "1");
            setPhase("home");
          }}
        />
      ) : null}
      {phase === "home" ? (
        <HomeScreen
          onRules={() => setRulesOpen(true)}
          onCreate={() => {
            setError(null);
            setPhase("create");
          }}
          onJoin={() => {
            setError(null);
            setPhase("join");
          }}
          onRehearse={() => {
            setError(null);
            setPhase("rehearse");
          }}
        />
      ) : null}
      {phase === "create" || phase === "join" || phase === "rehearse" ? (
        <SetupScreen
          mode={phase}
          busy={busy}
          initialCode={joinCode}
          error={error}
          onBack={() => {
            setError(null);
            setPhase("home");
          }}
          onSubmit={(value) => void submit(phase, value)}
        />
      ) : null}
      {phase === "lobby" && session ? (
        <LobbyScreen session={session} onRules={() => setRulesOpen(true)} onLeave={leave} onLive={onLive} />
      ) : null}
      {phase === "play" && session ? (
        <PlayScreen session={session} onRules={() => setRulesOpen(true)} onLeave={leave} />
      ) : null}
      {rulesOpen ? <RulesScreen review onDone={() => setRulesOpen(false)} /> : null}
    </>
  );
}
