export type Role = "seeker" | "hider";
export type NoteKind = "none" | "text" | "number";
export type GameStatus = "lobby" | "live" | "ended";

export type Place = {
  id: string;
  name: string;
  hint: string;
  lat: number;
  lng: number;
};

export type Task = {
  id: number;
  placeId: string;
  placeName: string;
  title: string;
  detail: string;
  lat: number;
  lng: number;
  radius: number;
  staySec: number;
  note: NoteKind;
};

export type TaskView = {
  id: number;
  title: string;
  detail: string;
  lat: number;
  lng: number;
  radius: number;
  staySec: number;
  note: NoteKind;
  done: boolean;
};

export type PingView = {
  lat: number;
  lng: number;
  ageSec: number;
  simulated: boolean;
};

export type RosterPlayer = {
  nickname: string;
  role: Role;
  team: string | null;
  immune: boolean;
  caught: boolean;
  scoreLeftMs: number | null;
  ping: PingView | null;
};

export type BumpView = {
  nickname: string;
  team: string | null;
  tasks: { title: string; done: boolean }[];
};

export type HuntState = {
  gameId: string;
  name: string;
  status: GameStatus;
  rehearsal: boolean;
  host: boolean;
  durationMs: number;
  remainingMs: number;
  paused: boolean;
  elapsedMs: number;
  nextPingMs: number;
  serverNow: number;
  me: {
    nickname: string;
    role: Role;
    team: string | null;
    tasks: TaskView[];
    immune: boolean;
    caught: boolean;
    scoreLeftMs: number | null;
    partner: string | null;
    doneCount: number;
  };
  roster: RosterPlayer[];
  bump: BumpView | null;
  catchable: { nickname: string } | null;
  seekerCount: number;
  hiderCount: number;
};

export const PING_MS = 10 * 60 * 1000;
export const TASK_RADIUS = 90;
export const BUMP_METERS = 35;
export const CATCH_METERS = 30;
export const SEEKERS = 2;
export const TASKS_PER_HIDER = 6;

/** The Spot (Nazih El Bizri) and Le Mall (south roundabout), Saida. */
export const MALLS = {
  spot: { name: "The Spot", lat: 33.565193, lng: 35.38002 },
  leMall: { name: "Le Mall", lat: 33.55769, lng: 35.37251 },
} as const;

export const FIELD_BOUNDS = {
  south: 33.5548,
  west: 35.3688,
  north: 33.5692,
  east: 35.3832,
};

const PLACES: Place[] = [
  {
    id: "spot-doors",
    name: "The Spot — main doors",
    hint: "Public entrance on Nazih El Bizri. Stay out of store aisles.",
    lat: 33.56519,
    lng: 35.38002,
  },
  {
    id: "spot-cinema",
    name: "The Spot — cinema side",
    hint: "Grand Cinemas side. The public hall is enough. No ticket needed.",
    lat: 33.56548,
    lng: 35.37948,
  },
  {
    id: "spot-park",
    name: "The Spot — parking sidewalk",
    hint: "Sidewalk by the parking. Do not stand in a driving lane.",
    lat: 33.56472,
    lng: 35.38035,
  },
  {
    id: "barad",
    name: "Barad crossing",
    hint: "Where the boulevard meets the Barad side. Use the sidewalk.",
    lat: 33.56455,
    lng: 35.3779,
  },
  {
    id: "boulevard",
    name: "Boulevard Mall — front sidewalk",
    hint: "Street side near Al Baba. Do not block the shop door.",
    lat: 33.5637,
    lng: 35.3772,
  },
  {
    id: "albaba",
    name: "Al Baba sidewalk",
    hint: "Public sidewalk only. Leave the counter clear.",
    lat: 33.56335,
    lng: 35.37655,
  },
  {
    id: "stadium",
    name: "Saida stadium — outer gate",
    hint: "Outside the gate only. Do not enter the pitch.",
    lat: 33.5601,
    lng: 35.3798,
  },
  {
    id: "garden",
    name: "Municipal garden gate",
    hint: "Stay on the public path.",
    lat: 33.56155,
    lng: 35.3764,
  },
  {
    id: "nejmeh",
    name: "Nejmeh Square",
    hint: "Stand out of the traffic.",
    lat: 33.56035,
    lng: 35.3751,
  },
  {
    id: "castle-hill",
    name: "Land castle overlook",
    hint: "Public view toward the land castle. Do not climb restricted walls.",
    lat: 33.56085,
    lng: 35.374,
  },
  {
    id: "east-gate",
    name: "Old city east gate",
    hint: "Where the old lanes meet the newer road. Stay with pedestrians.",
    lat: 33.56385,
    lng: 35.3737,
  },
  {
    id: "bab",
    name: "Bab al-Saray",
    hint: "Keep the old gate lane clear.",
    lat: 33.56415,
    lng: 35.37285,
  },
  {
    id: "khan",
    name: "Khan al-Franj entrance",
    hint: "The doorway. Step into the courtyard only if it is open to everyone.",
    lat: 33.56395,
    lng: 35.37195,
  },
  {
    id: "soap",
    name: "Soap khan lane",
    hint: "Souk lane. Do not touch goods that are for sale.",
    lat: 33.56345,
    lng: 35.37235,
  },
  {
    id: "debbane",
    name: "Debbane Palace lane",
    hint: "The lane outside. No ticket needed.",
    lat: 33.56315,
    lng: 35.37175,
  },
  {
    id: "sea",
    name: "Sea castle bridge",
    hint: "Public walk to Qalat al-Bahr. Do not climb the stonework.",
    lat: 33.5669,
    lng: 35.37155,
  },
  {
    id: "corniche",
    name: "Corniche benches",
    hint: "Benches facing the water. Leave seats for people who need them.",
    lat: 33.5659,
    lng: 35.37135,
  },
  {
    id: "port",
    name: "Fishermen's port rail",
    hint: "Public rail. Do not board a boat.",
    lat: 33.5657,
    lng: 35.37255,
  },
  {
    id: "nicholas",
    name: "Saint Nicholas square",
    hint: "Church square, exterior only.",
    lat: 33.56465,
    lng: 35.37315,
  },
  {
    id: "south-corniche",
    name: "South corniche",
    hint: "Seafront walk toward Dakerman. Stay on the path.",
    lat: 33.5594,
    lng: 35.3718,
  },
  {
    id: "roundabout",
    name: "Jezzine road crosswalk",
    hint: "Use the crosswalk. Do not stand in the roundabout.",
    lat: 33.5582,
    lng: 35.3734,
  },
  {
    id: "lemall-doors",
    name: "Le Mall — main doors",
    hint: "Public entrance. Stand to the side of the doors.",
    lat: 33.55769,
    lng: 35.37251,
  },
  {
    id: "lemall-park",
    name: "Le Mall — parking sidewalk",
    hint: "Sidewalk at the parking edge, not the lane.",
    lat: 33.55805,
    lng: 35.37315,
  },
  {
    id: "lemall-south",
    name: "Le Mall — south corner",
    hint: "South public corner of the mall block.",
    lat: 33.5572,
    lng: 35.3729,
  },
  {
    id: "bus",
    name: "Coastal bus stop",
    hint: "A public stop on the road between the malls. Stay on the curb.",
    lat: 33.5612,
    lng: 35.3727,
  },
];

type Verb = { title: string; detail: string; staySec: number; note: NoteKind };

const VERBS: Verb[] = [
  { title: "Hold still for one minute", detail: "Stand off to the side for 60 seconds. Do not block a door.", staySec: 60, note: "none" },
  { title: "Hold the edge for 45 seconds", detail: "Stay on public ground and let people pass.", staySec: 45, note: "none" },
  { title: "A long quiet hold", detail: "Stay 75 seconds. No shouting, no crowd.", staySec: 75, note: "none" },
  { title: "Count the lamps", detail: "Count street lamps you can see without crossing the road.", staySec: 20, note: "number" },
  { title: "First shop word", detail: "Read the nearest shop sign and type its first word.", staySec: 15, note: "text" },
  { title: "Sit, then return", detail: "Find a public bench or low wall, sit a moment, then hold the pin.", staySec: 40, note: "none" },
  { title: "Count the floors", detail: "How many floors does the tallest building in sight have?", staySec: 15, note: "number" },
  { title: "Name a door color", detail: "Type the color of the nearest door or shutter.", staySec: 15, note: "text" },
  { title: "Two languages", detail: "Find signs in two languages. Type one word from the second.", staySec: 20, note: "text" },
  { title: "Stand by a tree", detail: "Find a tree or large plant nearby and stay beside it.", staySec: 35, note: "none" },
  { title: "Count the arches", detail: "Count arches, columns, or window bays on the nearest facade.", staySec: 15, note: "number" },
  { title: "Face the open side", detail: "Put the sea, a court, or the open road on your left and hold.", staySec: 50, note: "none" },
  { title: "Something red", detail: "Find one red thing that is not a car. Type what it is.", staySec: 15, note: "text" },
  { title: "Street sign", detail: "Type the first word of the nearest street or mall sign.", staySec: 15, note: "text" },
  { title: "Count the motorbikes", detail: "Count bicycles and motorcycles you can see from the pin.", staySec: 15, note: "number" },
  { title: "Sky and a shop", detail: "Stand where you can see sky and a shopfront at the same time.", staySec: 40, note: "none" },
  { title: "Two steps from a bin", detail: "Find a public bin and stand two steps away. Do not touch it.", staySec: 30, note: "none" },
  { title: "Count the flags", detail: "How many flags or banners can you see? Type 0 if there are none.", staySec: 15, note: "number" },
  { title: "A café name", detail: "Type the first word of the nearest café. Do not order. Do not stop staff.", staySec: 15, note: "text" },
  { title: "Be findable", detail: "Hold still so a partner could spot you. Do not wave at seekers.", staySec: 55, note: "none" },
  { title: "Count steps", detail: "If a public stair is in sight, count the steps you see. If none, type 0.", staySec: 15, note: "number" },
  { title: "A number you can see", detail: "Type one number printed on a sign, clock, or poster.", staySec: 15, note: "text" },
  { title: "A color twice", detail: "Type a color you can see in two different places.", staySec: 20, note: "text" },
  { title: "Count the doorways", detail: "How many doorways are on the nearest facade?", staySec: 15, note: "number" },
  { title: "Off the flow", detail: "Stand out of the walking flow for 70 seconds.", staySec: 70, note: "none" },
  { title: "Ground color", detail: "Type the color of the tile or asphalt under you.", staySec: 15, note: "text" },
  { title: "Window count", detail: "Count the windows on one floor of the nearest building.", staySec: 15, note: "number" },
  { title: "A calm hold", detail: "Stay 50 seconds. Quiet is the point.", staySec: 50, note: "none" },
  { title: "Shade or sun", detail: "Type shade or sun for where you are standing.", staySec: 20, note: "text" },
  { title: "How many trees", detail: "How many trees can you see without crossing the road?", staySec: 15, note: "number" },
  { title: "One logo letter", detail: "Type the first letter of a brand logo you can see.", staySec: 15, note: "text" },
  { title: "Corner hold", detail: "Stand on the public corner, not in the road, for 40 seconds.", staySec: 40, note: "none" },
  { title: "Let people pass", detail: "Stay 35 seconds beside the flow. Do not block it.", staySec: 35, note: "none" },
  { title: "Awning color", detail: "Type the color of the nearest awning. If there is none, type none.", staySec: 15, note: "text" },
  { title: "Balcony count", detail: "How many balconies can you see on the facing building?", staySec: 15, note: "number" },
  { title: "Mall, sea, or street", detail: "Type mall, sea, or street for what is most in front of you.", staySec: 15, note: "text" },
  { title: "A short loop", detail: "Walk a short public loop nearby, then hold the pin again.", staySec: 30, note: "none" },
  { title: "What is the sign made of", detail: "Type metal, paint, or light for the nearest sign.", staySec: 15, note: "text" },
  { title: "Gate or open", detail: "Type gate if a gate is in sight. Otherwise type open.", staySec: 15, note: "text" },
  { title: "Plant color", detail: "Find a plant you can see and type its main color.", staySec: 20, note: "text" },
];

function jitter(lat: number, lng: number, n: number): { lat: number; lng: number } {
  const angle = ((n % 40) / 40) * Math.PI * 2;
  const meters = 10 + (n % 5) * 4;
  const dLat = (meters * Math.cos(angle)) / 111320;
  const dLng = (meters * Math.sin(angle)) / (111320 * Math.cos((lat * Math.PI) / 180));
  return { lat: lat + dLat, lng: lng + dLng };
}

function buildTasks(): Task[] {
  const tasks: Task[] = [];
  let id = 0;
  for (const place of PLACES) {
    for (const verb of VERBS) {
      const point = jitter(place.lat, place.lng, id);
      tasks.push({
        id,
        placeId: place.id,
        placeName: place.name,
        title: `${verb.title} · ${place.name}`,
        detail: `${verb.detail} Place: ${place.name}. ${place.hint} If the pin sits on a road, use the nearest sidewalk.`,
        lat: point.lat,
        lng: point.lng,
        radius: TASK_RADIUS,
        staySec: verb.staySec,
        note: verb.note,
      });
      id += 1;
    }
  }
  return tasks;
}

export const TASKS: Task[] = buildTasks();

if (TASKS.length !== 1000) {
  throw new Error(`Expected 1000 tasks, got ${TASKS.length}`);
}

const TASK_BY_ID = new Map(TASKS.map((task) => [task.id, task]));

export function taskById(id: number): Task | undefined {
  return TASK_BY_ID.get(id);
}

export function haversine(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const r = 6371000;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const lat1 = (aLat * Math.PI) / 180;
  const lat2 = (bLat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * r * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function formatClock(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  if (h > 0) return `${h}:${mm}:${ss}`;
  return `${mm}:${ss}`;
}

export function formatCode(code: string): string {
  const clean = code.toUpperCase();
  if (clean.length !== 6) return clean;
  return `${clean.slice(0, 3)} ${clean.slice(3)}`;
}

export function teamLetter(slot: number | null): string | null {
  if (slot == null || slot < 0) return null;
  if (slot < 26) return String.fromCharCode(65 + slot);
  return `T${slot + 1}`;
}

export function hashString(value: string): number {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function shuffleIds(seedKey: string, count: number): number[] {
  const ids = Array.from({ length: count }, (_, i) => i);
  let seed = hashString(seedKey) || 1;
  const rand = () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  for (let i = ids.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    const swap = ids[i];
    ids[i] = ids[j] ?? i;
    ids[j] = swap ?? j;
  }
  return ids;
}

export function inSaida(lat: number, lng: number): boolean {
  return haversine(lat, lng, 33.561, 35.375) < 25000;
}

export function walkStart(): { lat: number; lng: number } {
  return {
    lat: (MALLS.spot.lat + MALLS.leMall.lat) / 2,
    lng: (MALLS.spot.lng + MALLS.leMall.lng) / 2,
  };
}

export function noteOk(note: NoteKind, answer: string): boolean {
  const value = answer.trim();
  if (note === "none") return true;
  if (note === "number") return /^\d{1,3}$/.test(value);
  return value.length >= 1 && value.length <= 24 && !value.includes("<");
}
