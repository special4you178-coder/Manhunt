import { createServerFn } from "@tanstack/react-start";
import {
  BUMP_METERS,
  CATCH_METERS,
  PING_MS,
  SEEKERS,
  TASKS_PER_HIDER,
  type BumpView,
  type GameStatus,
  type HuntState,
  type NoteKind,
  type PingView,
  type Role,
  type RosterPlayer,
  type TaskView,
  haversine,
  noteOk,
  shuffleIds,
  taskById,
  teamLetter,
} from "./logic";

type Sql = Awaited<ReturnType<(typeof import("@/lib/db"))["getSql"]>>;

type GameRow = {
  id: string;
  name: string;
  duration_ms: number | string;
  status: string;
  rehearsal: boolean;
  host_token: string;
  started_ms: number | string | null;
  pause_started_ms: number | string | null;
  paused_total_ms: number | string;
  created_ms: number | string;
};

type PlayerRow = {
  token: string;
  game_id: string;
  nickname: string;
  role: string;
  team_slot: number | string | null;
  task_ids: string;
  done_ids: string;
  finished_ms: number | string | null;
  caught_ms: number | string | null;
  live_lat: number | string | null;
  live_lng: number | string | null;
  live_ms: number | string | null;
  live_simulated: boolean;
  ping_lat: number | string | null;
  ping_lng: number | string | null;
  ping_ms: number | string | null;
  ping_slot: number | string;
  ping_simulated: boolean;
  joined_ms: number | string;
};

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function num(value: unknown): number | null {
  if (value == null) return null;
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

function mustNum(value: unknown, fallback = 0): number {
  return num(value) ?? fallback;
}

function asRole(value: string): Role {
  return value === "seeker" ? "seeker" : "hider";
}

function asStatus(value: string): GameStatus {
  if (value === "live" || value === "ended") return value;
  return "lobby";
}

function ids(raw: string): number[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is number => typeof item === "number");
  } catch {
    return [];
  }
}

function cleanPerson(raw: unknown, label: string): string {
  if (typeof raw !== "string") throw new Error(`Enter a ${label}.`);
  const name = raw.trim().replace(/\s+/g, " ");
  if (name.length < 2 || name.length > 18) {
    throw new Error(`${label} should be 2 to 18 letters.`);
  }
  if (name.includes("@")) throw new Error("Use a name, not an email.");
  if (!/^[\p{L}\p{N} '\-]+$/u.test(name)) {
    throw new Error(`${label} can use letters, numbers, and spaces.`);
  }
  return name;
}

function cleanHuntName(raw: unknown): string {
  if (typeof raw !== "string") throw new Error("Name the hunt.");
  const name = raw.trim().replace(/\s+/g, " ");
  if (name.length < 2 || name.length > 32) {
    throw new Error("The hunt name should be 2 to 32 letters.");
  }
  if (/[<>]/.test(name)) throw new Error("Skip the symbols in the hunt name.");
  return name;
}

function cleanCode(raw: unknown): string {
  if (typeof raw !== "string") throw new Error("Enter the hunt code.");
  const code = raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (code.length !== 6) throw new Error("The hunt code is 6 letters.");
  return code;
}

function cleanRole(raw: unknown): Role {
  if (raw !== "seeker" && raw !== "hider") throw new Error("Pick seeker or hider.");
  return raw;
}

function cleanToken(raw: unknown): string {
  if (typeof raw !== "string" || !/^[a-f0-9]{32}$/.test(raw)) {
    throw new Error("This phone session is not valid. Join again.");
  }
  return raw;
}

function newToken(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

function newCode(): string {
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join("");
}

async function db(): Promise<Sql> {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

function elapsedMs(game: GameRow, now: number): number {
  const started = num(game.started_ms);
  if (started == null) return 0;
  const pausedTotal = mustNum(game.paused_total_ms);
  const pauseStarted = num(game.pause_started_ms);
  const openPause = pauseStarted == null ? 0 : Math.max(0, now - pauseStarted);
  return Math.max(0, now - started - pausedTotal - openPause);
}

async function loadGame(sql: Sql, gameId: string): Promise<GameRow> {
  const rows = await sql<GameRow>`select * from mh_games where id = ${gameId}`;
  const game = rows[0];
  if (!game) throw new Error("No hunt uses that code.");
  return game;
}

async function loadPlayers(sql: Sql, gameId: string): Promise<PlayerRow[]> {
  return sql<PlayerRow>`select * from mh_players where game_id = ${gameId} order by joined_ms asc`;
}

async function syncClock(sql: Sql, game: GameRow, now: number): Promise<GameRow> {
  if (game.status !== "live") return game;
  if (num(game.pause_started_ms) != null) return game;
  if (elapsedMs(game, now) < mustNum(game.duration_ms)) return game;
  await sql`update mh_games set status = 'ended' where id = ${game.id} and status = 'live'`;
  return { ...game, status: "ended" };
}

async function syncPings(sql: Sql, game: GameRow, players: PlayerRow[], now: number): Promise<PlayerRow[]> {
  if (game.status !== "live" || num(game.pause_started_ms) != null) return players;
  const slot = Math.floor(elapsedMs(game, now) / PING_MS);
  const next = players.map((player) => ({ ...player }));
  for (const player of next) {
    if (player.role !== "hider" || num(player.caught_ms) != null) continue;
    if (mustNum(player.ping_slot, -1) >= slot) continue;
    const lat = num(player.live_lat);
    const lng = num(player.live_lng);
    const liveMs = num(player.live_ms);
    if (lat == null || lng == null || liveMs == null) continue;
    if (now - liveMs > 3 * 60 * 1000) continue;
    await sql`update mh_players set ping_lat = ${lat}, ping_lng = ${lng}, ping_ms = ${liveMs}, ping_slot = ${slot}, ping_simulated = ${player.live_simulated} where token = ${player.token}`;
    player.ping_lat = lat;
    player.ping_lng = lng;
    player.ping_ms = liveMs;
    player.ping_slot = slot;
    player.ping_simulated = player.live_simulated;
  }
  return next;
}

async function dealTasks(sql: Sql, game: GameRow, players: PlayerRow[]): Promise<PlayerRow[]> {
  if (game.status === "lobby") return players;
  const hiders = players
    .filter((player) => player.role === "hider")
    .sort((a, b) => mustNum(a.joined_ms) - mustNum(b.joined_ms));
  if (hiders.length === 0) return players;
  const anyTeam = hiders.some((player) => num(player.team_slot) != null);
  const used = new Set(hiders.flatMap((player) => ids(player.task_ids)));
  const deck = shuffleIds(`${game.id}:tasks`, 1000).filter((id) => !used.has(id));
  let cursor = 0;
  for (let i = 0; i < hiders.length; i += 1) {
    const player = hiders[i];
    if (!player) continue;
    const currentSlot = num(player.team_slot);
    const slot = anyTeam ? currentSlot : Math.floor(i / 2);
    let taskIds = ids(player.task_ids);
    const needTasks = taskIds.length === 0;
    if (needTasks) {
      taskIds = deck.slice(cursor, cursor + TASKS_PER_HIDER);
      cursor += TASKS_PER_HIDER;
    }
    if (needTasks || slot !== currentSlot) {
      await sql`update mh_players set team_slot = ${slot}, task_ids = ${JSON.stringify(taskIds)} where token = ${player.token}`;
      player.team_slot = slot;
      player.task_ids = JSON.stringify(taskIds);
    }
  }
  return players;
}

function taskViews(taskIds: number[], done: number[]): TaskView[] {
  return taskIds.flatMap((id) => {
    const task = taskById(id);
    if (!task) return [];
    return [
      {
        id: task.id,
        title: task.title,
        detail: task.detail,
        lat: task.lat,
        lng: task.lng,
        radius: task.radius,
        staySec: task.staySec,
        note: task.note,
        done: done.includes(task.id),
      },
    ];
  });
}

function toState(game: GameRow, players: PlayerRow[], token: string, now: number): HuntState {
  const me = players.find((player) => player.token === token);
  if (!me) throw new Error("This phone is not in that hunt.");
  const duration = mustNum(game.duration_ms);
  const elapsed = game.status === "lobby" ? 0 : Math.min(duration, elapsedMs(game, now));
  const remaining = game.status === "lobby" ? duration : Math.max(0, duration - elapsed);
  const myTeam = num(me.team_slot);
  const showPings = me.role === "seeker" || game.rehearsal;
  const roster: RosterPlayer[] = players.map((player) => {
    const pingLat = num(player.ping_lat);
    const pingLng = num(player.ping_lng);
    const pingMs = num(player.ping_ms);
    let ping: PingView | null = null;
    if (showPings && player.role === "hider" && pingLat != null && pingLng != null && pingMs != null) {
      ping = {
        lat: pingLat,
        lng: pingLng,
        ageSec: Math.max(0, Math.round((now - pingMs) / 1000)),
        simulated: player.ping_simulated,
      };
    }
    const finished = num(player.finished_ms);
    return {
      nickname: player.nickname,
      role: asRole(player.role),
      team: teamLetter(num(player.team_slot)),
      immune: finished != null,
      caught: num(player.caught_ms) != null,
      scoreLeftMs: finished == null ? null : Math.max(0, duration - finished),
      ping,
    };
  });

  const partner =
    players.find(
      (player) =>
        player.token !== me.token &&
        player.role === "hider" &&
        myTeam != null &&
        num(player.team_slot) === myTeam,
    ) ?? null;

  let bump: BumpView | null = null;
  if (me.role === "hider" && num(me.caught_ms) == null && game.status === "live") {
    const myLat = num(me.live_lat);
    const myLng = num(me.live_lng);
    const myLive = num(me.live_ms);
    if (myLat != null && myLng != null && myLive != null && now - myLive < 45000) {
      let best: { player: PlayerRow; meters: number } | null = null;
      for (const other of players) {
        if (other.token === me.token || other.role !== "hider") continue;
        const lat = num(other.live_lat);
        const lng = num(other.live_lng);
        const live = num(other.live_ms);
        if (lat == null || lng == null || live == null || now - live > 45000) continue;
        const meters = haversine(myLat, myLng, lat, lng);
        if (meters > BUMP_METERS) continue;
        if (!best || meters < best.meters) best = { player: other, meters };
      }
      if (best) {
        const tasks = taskViews(ids(best.player.task_ids), ids(best.player.done_ids)).map((task) => ({
          title: task.title,
          done: task.done,
        }));
        bump = {
          nickname: best.player.nickname,
          team: teamLetter(num(best.player.team_slot)),
          tasks,
        };
      }
    }
  }

  let catchable: { nickname: string } | null = null;
  if (me.role === "seeker" && game.status === "live" && num(game.pause_started_ms) == null) {
    const myLat = num(me.live_lat);
    const myLng = num(me.live_lng);
    const myLive = num(me.live_ms);
    if (myLat != null && myLng != null && myLive != null && now - myLive < 45000) {
      let best: { nickname: string; meters: number } | null = null;
      for (const other of players) {
        if (other.role !== "hider" || num(other.caught_ms) != null || num(other.finished_ms) != null) continue;
        const lat = num(other.live_lat);
        const lng = num(other.live_lng);
        const live = num(other.live_ms);
        if (lat == null || lng == null || live == null || now - live > 45000) continue;
        const meters = haversine(myLat, myLng, lat, lng);
        if (meters > CATCH_METERS) continue;
        if (!best || meters < best.meters) best = { nickname: other.nickname, meters };
      }
      if (best) catchable = { nickname: best.nickname };
    }
  }

  const myDone = ids(me.done_ids);
  const myTasks = me.role === "hider" ? taskViews(ids(me.task_ids), myDone) : [];
  const finished = num(me.finished_ms);
  const intoPing = game.status === "live" ? elapsed % PING_MS : 0;

  return {
    gameId: game.id,
    name: game.name,
    status: asStatus(game.status),
    rehearsal: game.rehearsal,
    host: game.host_token === token,
    durationMs: duration,
    remainingMs: remaining,
    paused: num(game.pause_started_ms) != null,
    elapsedMs: elapsed,
    nextPingMs: game.status === "live" ? PING_MS - intoPing : PING_MS,
    serverNow: now,
    me: {
      nickname: me.nickname,
      role: asRole(me.role),
      team: teamLetter(myTeam),
      tasks: myTasks,
      immune: finished != null,
      caught: num(me.caught_ms) != null,
      scoreLeftMs: finished == null ? null : Math.max(0, duration - finished),
      partner: partner?.nickname ?? null,
      doneCount: myTasks.filter((task) => task.done).length,
    },
    roster,
    bump,
    catchable,
    seekerCount: players.filter((player) => player.role === "seeker").length,
    hiderCount: players.filter((player) => player.role === "hider").length,
  };
}

async function snapshot(gameId: string, token: string): Promise<HuntState> {
  const sql = await db();
  const now = Date.now();
  let game = await syncClock(sql, await loadGame(sql, gameId), now);
  let players = await loadPlayers(sql, gameId);
  players = await dealTasks(sql, game, players);
  players = await syncPings(sql, game, players, now);
  return toState(game, players, token, now);
}

async function insertPlayer(
  sql: Sql,
  gameId: string,
  token: string,
  nickname: string,
  role: Role,
  now: number,
): Promise<void> {
  const players = await loadPlayers(sql, gameId);
  if (players.some((player) => player.nickname.toLowerCase() === nickname.toLowerCase())) {
    throw new Error("That name is already in this hunt. Add an initial.");
  }
  if (role === "seeker" && players.filter((player) => player.role === "seeker").length >= SEEKERS) {
    throw new Error("Both seeker seats are taken. Join as a hider.");
  }
  if (role === "hider" && players.filter((player) => player.role === "hider").length >= 20) {
    throw new Error("This hunt already has 20 hiders.");
  }
  await sql`insert into mh_players (
    token, game_id, nickname, role, team_slot, task_ids, done_ids, joined_ms
  ) values (
    ${token}, ${gameId}, ${nickname}, ${role}, ${null}, ${"[]"}, ${"[]"}, ${now}
  )`;
}

export const createGame = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    const minutes = typeof body.minutes === "number" ? body.minutes : Number(body.minutes);
    if (!Number.isFinite(minutes) || minutes < 15 || minutes > 180) {
      throw new Error("Pick a length from 15 minutes to 3 hours.");
    }
    return {
      name: cleanHuntName(body.name),
      nickname: cleanPerson(body.nickname, "Your name"),
      role: body.rehearsal === true ? ("hider" as const) : cleanRole(body.role),
      minutes: Math.round(minutes),
      rehearsal: body.rehearsal === true,
    };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const now = Date.now();
    const token = newToken();
    let gameId = "";
    for (let attempt = 0; attempt < 6; attempt += 1) {
      const code = newCode();
      const clash = await sql<{ id: string }>`select id from mh_games where id = ${code}`;
      if (clash.length > 0) continue;
      gameId = code;
      break;
    }
    if (!gameId) throw new Error("Could not open a hunt. Try again.");
    const duration = data.minutes * 60 * 1000;
    const status = data.rehearsal ? "live" : "lobby";
    const started = data.rehearsal ? now : null;
    await sql`insert into mh_games (
      id, name, duration_ms, status, rehearsal, host_token, started_ms, paused_total_ms, created_ms
    ) values (
      ${gameId}, ${data.name}, ${duration}, ${status}, ${data.rehearsal}, ${token}, ${started}, ${0}, ${now}
    )`;
    await insertPlayer(sql, gameId, token, data.nickname, data.role, now);
    if (data.rehearsal) {
      const game = await loadGame(sql, gameId);
      const players = await loadPlayers(sql, gameId);
      await dealTasks(sql, game, players);
    }
    return { gameId, token };
  });

export const joinGame = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return {
      gameId: cleanCode(body.gameId),
      nickname: cleanPerson(body.nickname, "Your name"),
      role: cleanRole(body.role),
    };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const game = await loadGame(sql, data.gameId);
    if (game.rehearsal) throw new Error("That code is a one-phone rehearsal.");
    if (game.status !== "lobby") throw new Error("That hunt has already started.");
    const token = newToken();
    await insertPlayer(sql, data.gameId, token, data.nickname, data.role, Date.now());
    return { gameId: data.gameId, token };
  });

export const getState = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return { gameId: cleanCode(body.gameId), token: cleanToken(body.token) };
  })
  .handler(async ({ data }) => snapshot(data.gameId, data.token));

export const startGame = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return {
      gameId: cleanCode(body.gameId),
      token: cleanToken(body.token),
      force: body.force === true,
    };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const now = Date.now();
    const game = await loadGame(sql, data.gameId);
    if (game.host_token !== data.token) throw new Error("Only the host can start the hunt.");
    if (game.status !== "lobby") return snapshot(data.gameId, data.token);
    const players = await loadPlayers(sql, data.gameId);
    const seekers = players.filter((player) => player.role === "seeker").length;
    const hiders = players.filter((player) => player.role === "hider").length;
    if (!data.force && (seekers !== SEEKERS || hiders < 1)) {
      throw new Error("A real hunt needs 2 seekers and at least 1 hider.");
    }
    if (hiders < 1) throw new Error("Add at least one hider before you start.");
    await sql`update mh_games set status = 'live', started_ms = ${now} where id = ${game.id} and status = 'lobby'`;
    return snapshot(data.gameId, data.token);
  });

export const pairTeams = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return { gameId: cleanCode(body.gameId), token: cleanToken(body.token) };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const game = await loadGame(sql, data.gameId);
    if (game.host_token !== data.token) throw new Error("Only the host pairs the teams.");
    if (game.status !== "lobby") throw new Error("Teams lock when the hunt starts.");
    const players = await loadPlayers(sql, data.gameId);
    const hiders = players
      .filter((player) => player.role === "hider")
      .sort((a, b) => mustNum(a.joined_ms) - mustNum(b.joined_ms));
    for (let i = 0; i < hiders.length; i += 1) {
      const player = hiders[i];
      if (!player) continue;
      await sql`update mh_players set team_slot = ${Math.floor(i / 2)} where token = ${player.token}`;
    }
    return snapshot(data.gameId, data.token);
  });

export const teamUp = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return {
      gameId: cleanCode(body.gameId),
      token: cleanToken(body.token),
      withName: cleanPerson(body.withName, "Partner name"),
    };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const game = await loadGame(sql, data.gameId);
    if (game.status !== "lobby") throw new Error("Teams lock when the hunt starts.");
    const players = await loadPlayers(sql, data.gameId);
    const me = players.find((player) => player.token === data.token);
    if (!me) throw new Error("This phone is not in that hunt.");
    if (me.role !== "hider") throw new Error("Hiders team up with each other. The host can also pair everyone.");
    const other = players.find(
      (player) => player.nickname.toLowerCase() === data.withName.toLowerCase() && player.role === "hider",
    );
    if (!other || other.token === me.token) throw new Error("Pick another hider to team with.");
    const same = num(me.team_slot) != null && num(me.team_slot) === num(other.team_slot);
    if (same) {
      await sql`update mh_players set team_slot = ${null} where token = ${me.token} or token = ${other.token}`;
    } else {
      const used = players.map((player) => num(player.team_slot)).filter((slot): slot is number => slot != null);
      const slot = used.length ? Math.max(...used) + 1 : 0;
      if (num(me.team_slot) != null) {
        await sql`update mh_players set team_slot = ${null} where game_id = ${game.id} and team_slot = ${num(me.team_slot)} and token <> ${other.token}`;
      }
      if (num(other.team_slot) != null) {
        await sql`update mh_players set team_slot = ${null} where game_id = ${game.id} and team_slot = ${num(other.team_slot)} and token <> ${me.token}`;
      }
      await sql`update mh_players set team_slot = ${slot} where token = ${me.token} or token = ${other.token}`;
    }
    return snapshot(data.gameId, data.token);
  });

export const setLocation = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    const lat = typeof body.lat === "number" ? body.lat : Number(body.lat);
    const lng = typeof body.lng === "number" ? body.lng : Number(body.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
      throw new Error("That location does not look right.");
    }
    return {
      gameId: cleanCode(body.gameId),
      token: cleanToken(body.token),
      lat,
      lng,
      simulated: body.simulated === true,
    };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const now = Date.now();
    await sql`update mh_players set live_lat = ${data.lat}, live_lng = ${data.lng}, live_ms = ${now}, live_simulated = ${data.simulated} where token = ${data.token} and game_id = ${data.gameId}`;
    return snapshot(data.gameId, data.token);
  });

export const togglePause = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return { gameId: cleanCode(body.gameId), token: cleanToken(body.token) };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const now = Date.now();
    const game = await loadGame(sql, data.gameId);
    if (game.status !== "live") throw new Error("The clock is not running.");
    const players = await loadPlayers(sql, data.gameId);
    if (!players.some((player) => player.token === data.token)) {
      throw new Error("This phone is not in that hunt.");
    }
    const pauseStarted = num(game.pause_started_ms);
    if (pauseStarted == null) {
      await sql`update mh_games set pause_started_ms = ${now} where id = ${game.id} and pause_started_ms is null`;
    } else {
      const extra = Math.max(0, now - pauseStarted);
      await sql`update mh_games set pause_started_ms = ${null}, paused_total_ms = paused_total_ms + ${extra} where id = ${game.id}`;
    }
    return snapshot(data.gameId, data.token);
  });

export const completeTask = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    const taskId = typeof body.taskId === "number" ? body.taskId : Number(body.taskId);
    if (!Number.isInteger(taskId)) throw new Error("Pick a task.");
    return {
      gameId: cleanCode(body.gameId),
      token: cleanToken(body.token),
      taskId,
      answer: typeof body.answer === "string" ? body.answer : "",
    };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const now = Date.now();
    const game = await syncClock(sql, await loadGame(sql, data.gameId), now);
    if (game.status !== "live") throw new Error("Tasks open only while the hunt is live.");
    if (num(game.pause_started_ms) != null) throw new Error("The hunt is paused for prayer.");
    const players = await loadPlayers(sql, data.gameId);
    const me = players.find((player) => player.token === data.token);
    if (!me || me.role !== "hider") throw new Error("Only hiders complete tasks.");
    if (num(me.caught_ms) != null) throw new Error("You were caught. Tasks are locked.");
    if (num(me.finished_ms) != null) throw new Error("You already finished. You are immune.");
    const mine = ids(me.task_ids);
    if (!mine.includes(data.taskId)) throw new Error("That task is not yours.");
    const task = taskById(data.taskId);
    if (!task) throw new Error("That task is missing.");
    if (!noteOk(task.note as NoteKind, data.answer)) {
      throw new Error(task.note === "number" ? "Type the number you counted." : "Type a short answer you can see.");
    }
    const lat = num(me.live_lat);
    const lng = num(me.live_lng);
    const live = num(me.live_ms);
    if (lat == null || lng == null || live == null || now - live > 60000) {
      throw new Error("Your phone has no fresh location. Enable location or tap the map.");
    }
    if (haversine(lat, lng, task.lat, task.lng) > task.radius) {
      throw new Error("Get closer to the pin before you mark this done.");
    }
    const done = ids(me.done_ids);
    if (!done.includes(data.taskId)) done.push(data.taskId);
    const elapsed = elapsedMs(game, now);
    const finished = done.length >= mine.length ? elapsed : null;
    await sql`update mh_players set done_ids = ${JSON.stringify(done)}, finished_ms = ${finished} where token = ${me.token}`;
    return snapshot(data.gameId, data.token);
  });

export const catchHider = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const body = (data ?? {}) as Record<string, unknown>;
    return { gameId: cleanCode(body.gameId), token: cleanToken(body.token) };
  })
  .handler(async ({ data }) => {
    const sql = await db();
    const now = Date.now();
    const game = await loadGame(sql, data.gameId);
    if (game.status !== "live") throw new Error("The hunt is not live.");
    if (num(game.pause_started_ms) != null) throw new Error("Nobody is caught during prayer.");
    const players = await loadPlayers(sql, data.gameId);
    const me = players.find((player) => player.token === data.token);
    if (!me || me.role !== "seeker") throw new Error("Only a seeker can confirm a catch.");
    const lat = num(me.live_lat);
    const lng = num(me.live_lng);
    const live = num(me.live_ms);
    if (lat == null || lng == null || live == null || now - live > 45000) {
      throw new Error("Your location is stale. Stand with them and try again.");
    }
    let best: { token: string; meters: number } | null = null;
    for (const other of players) {
      if (other.role !== "hider" || num(other.caught_ms) != null || num(other.finished_ms) != null) continue;
      const oLat = num(other.live_lat);
      const oLng = num(other.live_lng);
      const oLive = num(other.live_ms);
      if (oLat == null || oLng == null || oLive == null || now - oLive > 45000) continue;
      const meters = haversine(lat, lng, oLat, oLng);
      if (meters > CATCH_METERS) continue;
      if (!best || meters < best.meters) best = { token: other.token, meters };
    }
    if (!best) throw new Error("No hider is close enough, or they are already immune.");
    await sql`update mh_players set caught_ms = ${elapsedMs(game, now)} where token = ${best.token} and caught_ms is null and finished_ms is null`;
    return snapshot(data.gameId, data.token);
  });
