import { useCallback, useEffect, useRef, useState } from "react";
import { Capacitor, registerPlugin } from "@capacitor/core";
import type { BackgroundGeolocationPlugin } from "@capacitor-community/background-geolocation";

const BackgroundGeolocation = registerPlugin<BackgroundGeolocationPlugin>("BackgroundGeolocation");

export type LocationStatus = "waiting" | "ok" | "denied" | "unavailable";
export type LocationFix = { lat: number; lng: number; accuracy: number; at: number };

export const isNative = (): boolean => Capacitor.isNativePlatform();

/**
 * One location source for both worlds.
 *  - Native app: background-capable watcher (Android foreground service with a
 *    notification, iOS "location" background mode). `onFix` fires even when the
 *    screen is locked, so uploads are driven by it, not by React timers.
 *  - Browser: plain watchPosition (foreground only).
 */
export function useBackgroundLocation(onFix?: (fix: LocationFix) => void) {
  const [fix, setFix] = useState<LocationFix | null>(null);
  const [status, setStatus] = useState<LocationStatus>("waiting");
  const onFixRef = useRef(onFix);
  onFixRef.current = onFix;
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    let stopped = false;
    let watcherId: string | null = null;
    let webId: number | null = null;

    const accept = (lat: number, lng: number, accuracy: number) => {
      if (stopped) return;
      const next = { lat, lng, accuracy, at: Date.now() };
      setFix(next);
      setStatus("ok");
      onFixRef.current?.(next);
    };

    if (isNative()) {
      void BackgroundGeolocation.addWatcher(
        {
          backgroundTitle: "Manhunt is running",
          backgroundMessage: "Sharing your location while the hunt is live.",
          requestPermissions: true,
          stale: false,
          distanceFilter: 5,
        },
        (location, error) => {
          if (error) {
            if (!stopped) setStatus(error.code === "NOT_AUTHORIZED" ? "denied" : "unavailable");
            return;
          }
          if (location) accept(location.latitude, location.longitude, location.accuracy ?? 50);
        },
      ).then((id) => {
        if (stopped) void BackgroundGeolocation.removeWatcher({ id });
        else watcherId = id;
      });
    } else if (navigator.geolocation) {
      webId = navigator.geolocation.watchPosition(
        (pos) => accept(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy),
        (err) => setStatus(err.code === err.PERMISSION_DENIED ? "denied" : "unavailable"),
        { enableHighAccuracy: true, maximumAge: 4000, timeout: 12000 },
      );
    } else {
      setStatus("unavailable");
    }

    return () => {
      stopped = true;
      if (watcherId) void BackgroundGeolocation.removeWatcher({ id: watcherId });
      if (webId != null) navigator.geolocation.clearWatch(webId);
    };
  }, [nonce]);

  /** Re-arm the watcher (after the player changed a setting). */
  const retry = useCallback(() => setNonce((n) => n + 1), []);
  /** Native: open the OS settings page for this app. */
  const openSettings = useCallback(() => {
    if (isNative()) void BackgroundGeolocation.openSettings();
    else retry();
  }, [retry]);

  return { fix, status, retry, openSettings };
}
