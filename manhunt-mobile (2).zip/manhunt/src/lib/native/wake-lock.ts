import { useEffect } from "react";

/**
 * Browsers pause GPS the moment the screen locks, so for the link/home-screen
 * version we keep the screen awake while a hunt is live. Re-acquired whenever
 * the app returns to the foreground (the lock is released when hidden).
 */
export function useKeepAwake(active: boolean) {
  useEffect(() => {
    if (!active || !("wakeLock" in navigator)) return;
    let lock: WakeLockSentinel | null = null;
    let gone = false;
    const grab = async () => {
      try {
        lock = await navigator.wakeLock.request("screen");
      } catch {
        // Denied (e.g. low battery mode). The hunt still works with the screen on.
      }
    };
    const onVisible = () => {
      if (document.visibilityState === "visible" && !gone) void grab();
    };
    void grab();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      gone = true;
      document.removeEventListener("visibilitychange", onVisible);
      void lock?.release().catch(() => undefined);
    };
  }, [active]);
}
