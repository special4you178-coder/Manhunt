create table if not exists mh_games (
  id text primary key,
  name text not null,
  duration_ms integer not null,
  status text not null,
  rehearsal boolean not null default false,
  host_token text not null,
  started_ms bigint,
  pause_started_ms bigint,
  paused_total_ms bigint not null default 0,
  created_ms bigint not null
);

create table if not exists mh_players (
  token text primary key,
  game_id text not null,
  nickname text not null,
  role text not null,
  team_slot integer,
  task_ids text not null default '[]',
  done_ids text not null default '[]',
  finished_ms bigint,
  caught_ms bigint,
  live_lat double precision,
  live_lng double precision,
  live_ms bigint,
  live_simulated boolean not null default false,
  ping_lat double precision,
  ping_lng double precision,
  ping_ms bigint,
  ping_slot integer not null default -1,
  ping_simulated boolean not null default false,
  joined_ms bigint not null
);

create index if not exists mh_players_game_idx on mh_players (game_id);
create unique index if not exists mh_players_name_uq on mh_players (game_id, lower(nickname));
